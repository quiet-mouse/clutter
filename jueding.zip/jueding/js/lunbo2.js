(function(){
	
	var oBox2 = document.getElementById("box2");
	var oList = oBox2.getElementsByTagName("ul")[0];
	var aImg = oBox2.getElementsByTagName("img");
	var timer = playTimer = null;
	var index = i = 0;
	var bOrder = true;
	var aTmp = [];
	var aBtn = null;

	for(var i=0; i<aImg.length; i++){
		aTmp.push("<li></li>");	//push() 方法可向数组的末尾添加一个或多个元素，并返回新的长度。
	}
	var oCount = document.createElement("ul");
	oCount.className = "count";
	oCount.innerHTML = aTmp.join("");
	oBox2.appendChild(oCount);
	aBtn = oBox2.getElementsByTagName("ul")[1].getElementsByTagName("li");

	cutover();

	for (i = 0; i < aBtn.length; i++)
	{
		aBtn[i].index = i;
		aBtn[i].onmouseover = function ()
		{
			index = this.index;
			cutover();
		}
	}

	function cutover()
	{
		for (i = 0; i < aBtn.length; i++) aBtn[i].className = "";
		aBtn[index].className = "current";			
		startMove(-(index * aImg[0].offsetWidth))
	}

	function next()
	{
		bOrder ? index++ : index--;
		index <= 0 && (index = 0, bOrder = true);
		index >= aBtn.length - 1 && (index = aBtn.length - 1, bOrder = false)
		cutover()
	}

	playTimer = setInterval(next, 2000);

	// //鼠标移入展示区停止自动播放
	// oBox2.onmouseover = function ()
	// {
	// 	clearInterval(playTimer)
	// };
	// //鼠标离开展示区开始自动播放
	// oBox2.onmouseout = function ()
	// {
	// 	playTimer = setInterval(next, 3000)
	// };
	
	function startMove(iTarget)
	{
		clearInterval(timer);
		timer = setInterval(function ()
		{
			doMove(iTarget)
		}, 30)	
	}
	function doMove (iTarget)
	{		
		var iSpeed = (iTarget - oList.offsetLeft) / 10;
		iSpeed = iSpeed > 0 ? Math.ceil(iSpeed) : Math.floor(iSpeed);		
		oList.offsetLeft == iTarget ? clearInterval(timer) : oList.style.left = oList.offsetLeft + iSpeed + "px"
	}

})();