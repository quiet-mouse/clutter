(function(){
	var ml = $(".mulu");
	setInterval(function(){
		ml.removeClass("animated flash");
		setTimeout(function(){
			ml.addClass("animated flash");
		},200)
	},2000);
})();